#include<stdio.h>
#include<stdlib.h>

#define CR 13
#define END_OF_STREAM 255

void main(void)
{
	char 
		ch;

	while ((ch = getchar()) != END_OF_STREAM) {
		if (ch != CR) putchar(ch);
	}
}


