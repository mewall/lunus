#include<stdio.h>
#include<stdlib.h>
#include<string.h>

#define SPACE 32

void main(void)
{
	char 
		inline[255],
		workstr[255],
		*ch;
	
	while (gets(inline) != NULL) {
		strcpy(workstr,inline);
		ch = strchr(workstr,SPACE);
		*ch = 0;
		if (strcmp(workstr,"pcat") != 0) {
			strcpy(workstr, ch + 1);
			ch = strchr(workstr,SPACE);
			*ch = 0;
			strcpy(workstr, ch + 1);
			ch = strchr(workstr, SPACE);
			*ch = 0;
			printf("groff -man -Tascii %s | more -s -f\n", 
					workstr);
		}
		else {
			inline[strlen(inline)-1] = 0;
			strcat(inline,"l| ul | more -s -f");
			puts(inline);
		}
	}

}


