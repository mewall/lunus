#include<stdio.h>
#include<stdlib.h>

main()
{
	char 
		ch=0;
	do {
		putchar(ch);
		ch = getchar();
	} while (ch != 255);	
}


