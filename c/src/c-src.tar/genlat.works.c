/* GENLAT.C - Create a 3D lattice based upon an input list of
              diffraction images and index files.
   
   Author: Mike Wall
   Date: 2/22/95
   Version: 1.

   Usage:

   "genlat <output file > <inner radius cutoff> <outer radius cutoff> <minrange>"

      A list in the form of:

      <index file> <image file> <scale factor>

      must be supplied at standard input, terminated by '.' in the
      first character of the line.

   */

#include<mwmask.h>

void main(int argc, char *argv[])
{
  FILE
    *infile,
    *outfile,
    *imagein;
  
  char
    *info_string,
    *space_ptr,
    input_line[LINESIZE],
    error_msg[LINESIZE];
  
  size_t
    *ct,
    num_values,
    num_wrote,
    num_read,
    map_index,
    index,
    i,
    j,
    k;

  int
    hh,
    kk,
    ll;
  
  DIFFIMAGE 
    *imdiff;

  LAT3D
    *lat;

  struct voxel
    *map3D,
    *voxel_data;

  struct xyzcoords
    dist,
    pos;

  float
    minrange,
    q_squared,
    inner_radius,
    inner_radius_sq,
    outer_radius,
    outer_radius_sq,
    scale;

  /*
   * Set input line defaults:
   */
  
  scale=1;
  outfile = stdout;
  inner_radius= DEFAULT_INNER_RADIUS_LT;
  outer_radius = DEFAULT_OUTER_RADIUS_LT;
  inner_radius_sq = inner_radius*inner_radius;
  outer_radius_sq = DEFAULT_BOUND_MAX*DEFAULT_BOUND_MAX;

  switch(argc) {    
    case 5:
    minrange = atof(argv[4]);
    case 4:
    outer_radius = atof(argv[3]);
    outer_radius_sq = outer_radius*outer_radius;
    case 3:
    inner_radius = atof(argv[2]);
    inner_radius_sq = inner_radius*inner_radius;
    case 2:
    if (strcmp(argv[1],"-") == 0) {
      outfile = stdout;
    }
    else {
      if ( (outfile = fopen(argv[1],"wb")) == NULL ) {
	printf("\nCan't open %s.\n\n",argv[1]);
	exit(0);
      }
    }
    break;
    default:
    printf("\n Usage: genlat <output file> <inner radius> "
	   "<outer radius> <minrange>\n\n");
    exit(0);
  }

/*
 * Initialize diffraction image:
 */

  if ((imdiff = linitim()) == NULL) {
    perror("Couldn't initialize diffraction image.\n\n");
    exit(0);
  }

  
  /*
   * Allocate memory:
   */
  
  map3D = (struct voxel *)malloc(sizeof(struct voxel)*imdiff->image_length);
  if (!map3D) {
    printf("\n***Unable to allocate map3D.\n");
    goto CloseShop;
  }

  /*
   * Initialize lattice:
   */

  if ((lat = linitlt()) == NULL) {
    perror("Couldn't initialize lattice.n\n");
    exit(0);
  }

  
  
  /*
   * Set main defaults:
   */
  
  lat->map3D = map3D;
  lat->minrange.x = lat->minrange.y = lat->minrange.z = minrange;
  
  /*
   * Allocate ct:
   */
  
  ct = (size_t *)calloc(lat->lattice_length,sizeof(size_t));
  if (!ct) {
    printf("\nNot enough room to allocate counting table ct.\n\n");
    exit(0);
  }

  /*
   * Loop through input lines until '.' is encountered.
   */

  while ((*gets(input_line) != '.') && (input_line != NULL)) {
    printf("%s\n",input_line);
    info_string = input_line;
    space_ptr = strchr(info_string,' ');
    *space_ptr = 0;
    if ( (infile = fopen(info_string,"r")) == NULL ) {
      printf("\nCan't open index file %s.\n\n",info_string);
      exit(0);
    }
    info_string = space_ptr+1;
    space_ptr = strchr(info_string,' ');
    *space_ptr = 0;
    if ( (imagein = fopen(info_string,"rb")) == NULL ) {
      printf("\nCan't open image %s.\n\n",info_string);
      exit(0);
    }
    info_string = space_ptr+1;
    if (info_string != "") {
      scale = atof(info_string);
    } else {
      scale = 1.;
    }

    /*
     * Read input file which contains the orientation matrix:
     */
    
    imdiff->infile = infile;
    lgetmat(imdiff);

    /*
     * Read diffraction image:
     */
    
    imdiff->infile = imagein;
    if (lreadim(imdiff) != 0) {
      perror(imdiff->error_msg);
      goto CloseShop;
    }

    /*
     * Step through the image and generate the map:
     */
    
    map_index = 0;
    for (i=0; i<imdiff->vpixels; i++) {
      imdiff->pos.r = i; 
      for (j=0; j<imdiff->hpixels; j++) {
	imdiff->pos.c = j;
	imdiff->map3D = &map3D[map_index];
	lgensv(imdiff);
	map_index++;
      }
    }
    
    /*
     * Scale the values to the input line scale:
     */
    
    for(map_index=0; map_index<imdiff->image_length; map_index++) {
      map3D[map_index].value *= scale;
    }
    
    /*
     * Step through the map and fill the lattice:
     */

    for(map_index=0; map_index<imdiff->image_length; map_index++) {
      voxel_data = &map3D[map_index];
/*printf("%d : %f, %f, %f, %f\n",map_index,voxel_data->pos.x,voxel_data->pos.y,voxel_data->pos.z,voxel_data->value);/***/
      q_squared = (voxel_data->pos.x*voxel_data->pos.x +
		   voxel_data->pos.y*voxel_data->pos.y +
		   voxel_data->pos.z*voxel_data->pos.z);
      if ((inner_radius_sq < q_squared) && (outer_radius_sq >
					    q_squared)) {
	if (voxel_data->pos.x < 0) {
	  hh = (int)(voxel_data->pos.x - .5);
	} else {
	  hh = (int)(voxel_data->pos.x + .5);
	}
	if (voxel_data->pos.y < 0) {
	  kk = (int)(voxel_data->pos.y - .5);
	} else {
	  kk = (int)(voxel_data->pos.y + .5);
	}
	if (voxel_data->pos.z < 0) {
	  ll = (int)(voxel_data->pos.z - .5);
	} else {
	  ll = (int)(voxel_data->pos.z + .5);
	}
	i = (size_t) ((pos.x - lat->xbound.min + .5)*lat->xscale ); 
	j = (size_t) ((pos.y - lat->ybound.min + .5)*lat->yscale ); 
	k = (size_t) ((pos.z - lat->zbound.min + .5)*lat->zscale ); 
	dist.x = (float)fabsf(voxel_data->pos.x - (float)hh);
	dist.y = (float)fabsf(voxel_data->pos.y - (float)kk);
	dist.z = (float)fabsf(voxel_data->pos.z - (float)ll);
	if ((voxel_data->value != lat->mask_tag) && 
	    (voxel_data->value != 0) &&
	    (dist.x > lat->minrange.x) &&
	    (dist.y > lat->minrange.y) &&
	    (dist.z > lat->minrange.z)) {
	  index = k*lat->xyvoxels + j*lat->xvoxels + i;
	  if (index >= lat->lattice_length) {
	    printf("\nTried to index lattice outside of range.\n");
	    goto CloseShop;
	  }
	  if (ct[index == 0]) {
	    lat->lattice[index] = (LATTICE_DATA_TYPE)voxel_data->value;
	    ct[index]++;
	  } else {
	    lat->lattice[index] =
	      (LATTICE_DATA_TYPE)(((float)ct[index]*lat->lattice[index] + 
				   voxel_data->value)
				  /(float)(ct[index]+1.));
	    ct[index]++;
	  }
	}
      }
    }

    /* 
     * Close input files:
     */
    
    fclose(infile);
    fclose(imagein);
  }

  /*
   * Write lattice to output file:
   */
  
  lat->outfile = outfile;
  if (lwritelt(lat) != 0) {
    perror("Couldn't write lattice.\n\n");
    exit(0);
  }
  
  CloseShop:
  
  /*
   * Free allocated memory:
   */
  
  lfreeim(imdiff);
  lfreelt(lat);
  free((struct voxel *)map3D);
  free((size_t *)ct);
  
  /*
   * Close files:
   */
  
  fclose(outfile);
}


