void main()
{
	int i;

	for(i=0;i<100;i++) {
		printf("Line number %d.\n",i);
	}
}

